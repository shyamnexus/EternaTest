import{e}from"./chunk-TSRGIXR5.js";var p=e((s,t)=>{t.exports=XMLHttpRequest});export default p();
