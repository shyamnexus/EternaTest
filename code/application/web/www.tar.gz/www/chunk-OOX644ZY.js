import{d as q,e as Q,f as ee,h as a,j as w,k as u,l as y,m as C}from"./chunk-CRKX3EUW.js";import{a as X}from"./chunk-24A4VFLD.js";import{b as T}from"./chunk-45H3YV4H.js";import{c as k,d as B,g as H}from"./chunk-2SMDLGXQ.js";import{c as z}from"./chunk-QNBJZPFD.js";import{b as Z}from"./chunk-HD44J7K5.js";import{i as W}from"./chunk-T5R7SCXD.js";import{a as K,b as Y}from"./chunk-B2NCVVXK.js";import{f as J}from"./chunk-YJOFRLFH.js";import{a as N}from"./chunk-MRCTGD5K.js";import{c as P}from"./chunk-LRM3FSCR.js";import{b as U}from"./chunk-3FGEHB5V.js";import{a as F}from"./chunk-WFOIHGOF.js";import{Oa as $,ha as V,s as E,w as j}from"./chunk-YZUR3EED.js";import{Ga as M,Ib as s,Jb as g,Kb as x,Ob as O,Sb as v,Z as l,_a as R,ba as f,bc as _,cc as m,db as o,ka as h,kb as L,la as A,lb as n,yb as b}from"./chunk-BY7P3Y36.js";import{a as r}from"./chunk-TSRGIXR5.js";var D=(()=>{class e{}return e.\u0275fac=function(t){return new(t||e)},e.\u0275mod=n({type:e}),e.\u0275inj=l({imports:[a]}),e})();var S=(()=>{class e{}return e.\u0275fac=function(t){return new(t||e)},e.\u0275mod=n({type:e}),e.\u0275inj=l({imports:[a,$]}),e})();var I=(()=>{class e{}return e.\u0275fac=function(t){return new(t||e)},e.\u0275mod=n({type:e}),e.\u0275inj=l({imports:[a]}),e})();var de=(()=>{class e{constructor(t,i){j(i)&&!t&&console.warn("Warning: Flex Layout loaded on the server without FlexLayoutServerModule")}static withConfig(t,i=[]){return{ngModule:e,providers:t.serverLoaded?[{provide:u,useValue:r(r({},w),t)},{provide:C,useValue:i,multi:!0},{provide:y,useValue:!0}]:[{provide:u,useValue:r(r({},w),t)},{provide:C,useValue:i,multi:!0}]}}}return e.\u0275fac=function(t){return new(t||e)(f(y),f(M))},e.\u0275mod=n({type:e}),e.\u0275inj=l({imports:[S,D,I,S,D,I]}),e})();var gt=(()=>{class e{constructor(t,i,c){this.loginService=t,this.router=i,this.dialog=c,this.appVersion=F.appVersion,this.currentUserRole="",this.settingsChanged=!1}ngOnInit(){this.loginService.currentSettingsChanged.subscribe(i=>{this.settingsChanged=i});let t=this.loginService.getCurrentUser();this.currentUserRole=t?.role||""}onLogout(){document.activeElement instanceof HTMLElement&&document.activeElement.blur(),this.loginService.logout().subscribe(t=>{t&&t.status==="success"?this.router.navigate(["/login"]):t?.message&&this.openDialog(t?.message)},t=>{console.error("Error when logging out user",t)})}showUserDetail(){let t=this.loginService.getCurrentUser();return this.currentUserRole=t?.role||"",t?.username??""}showVersionDetail(){return"V "+F.appVersion}isViewer(){return(this.loginService.getCurrentUser()?.role?.toLowerCase()||"")==="viewer"}canAccessConfig(){return!this.isViewer()}openDialog(t){this.dialog.open(N,{width:"400px",data:{message:t}})}onConfigButtonClick(){this.settingsChanged}static{this.\u0275fac=function(i){return new(i||e)(o(T),o(k),o(P))}}static{this.\u0275cmp=L({type:e,selectors:[["app-topbar"]],decls:17,vars:2,consts:[["userTooltip","matTooltip"],[1,"modern-toolbar"],[1,"logo-container"],["routerLink","/live-view","src","../../../../assets/Images/IMPACT-by-honeywell.png","alt","Impact by Honeywell",1,"logo-image"],[1,"user-actions"],[1,"user-profile",3,"click","matTooltip","matTooltipPosition"],[1,"user-avatar"],[1,"fas","fa-user"],[1,"user-info"],[1,"user-name"],[1,"user-role"],["matTooltip","Logout","matTooltipPosition","below",1,"logout-btn",3,"click"],[1,"fas","fa-sign-out-alt"]],template:function(i,c){if(i&1){let G=O();s(0,"mat-toolbar",1)(1,"div",2),x(2,"img",3),g(),s(3,"div",4)(4,"div",5,0),v("click",function(){h(G);let ae=_(5);return A(ae.show())}),s(6,"div",6),x(7,"i",7),g(),s(8,"div",8)(9,"span",9),m(10,"Admin"),g(),s(11,"span",10),m(12,"Administrator"),g()()(),s(13,"button",11),v("click",function(){return h(G),A(c.onLogout())}),x(14,"i",12),s(15,"span"),m(16,"Logout"),g()()()()}i&2&&(R(4),b("matTooltip",c.showUserDetail())("matTooltipPosition","below"))},dependencies:[E,H,B,de,ee,Q,J,q,U,X,Z,V,z,W,Y,K],styles:['.modern-toolbar[_ngcontent-%COMP%]{background:#2a3744;padding:12px 64px 12px 24px;min-height:64px;box-shadow:0 2px 8px #10182814;display:flex;justify-content:space-between;align-items:center;position:relative;width:100%;box-sizing:border-box;color:#fff}.logo-container[_ngcontent-%COMP%]{display:flex;align-items:center;min-width:200px}.logo-image[_ngcontent-%COMP%]{height:40px;width:auto;filter:none;transition:all .2s ease}.logo-image[_ngcontent-%COMP%]:hover{transform:scale(1.05)}.nav-center[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;flex:1;justify-content:center}.nav-link[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;padding:10px 18px;color:#222;text-decoration:none;border-radius:10px;font-weight:500;font-size:14px;transition:background .18s ease,transform .18s ease;position:relative;background:transparent}.nav-link[_ngcontent-%COMP%]:hover{background:#ff6b3514;transform:translateY(-2px)}.nav-link.active[_ngcontent-%COMP%]{background:#ff6b351f;color:#ff6b35;box-shadow:none}.nav-link.active[_ngcontent-%COMP%]:after{content:"";position:absolute;bottom:8px;left:50%;transform:translate(-50%);width:28px;height:3px;background:#ff6b35;border-radius:2px}.nav-icon[_ngcontent-%COMP%]{font-size:16px;color:inherit;opacity:.95}.user-actions[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;min-width:200px;justify-content:flex-end}.user-profile[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;padding:4px 10px;background:#ee6b1e;border-radius:50px;cursor:pointer;transition:all .2s ease;box-shadow:0 1px 2px #ee6b1e33}.user-profile[_ngcontent-%COMP%]:hover{background:#d5601a;box-shadow:0 2px 4px #ee6b1e4d}.user-avatar[_ngcontent-%COMP%]{width:32px;height:32px;border-radius:50%;background:#fff;color:#ee6b1e;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:14px;box-shadow:0 2px 4px #00000014}.user-info[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:flex-start}.user-name[_ngcontent-%COMP%]{color:#24292e;font-size:13px;font-weight:600;line-height:1.2}.user-role[_ngcontent-%COMP%]{color:#24292e;font-size:10px;line-height:1.2;opacity:.8}.logout-btn[_ngcontent-%COMP%]{background:#ee6b1e;border:none;color:#24292e;padding:6px 12px;border-radius:6px;font-size:13px;cursor:pointer;transition:all .2s ease;display:flex;align-items:center;gap:6px;box-shadow:0 1px 2px #ee6b1e33}.logout-btn[_ngcontent-%COMP%]:hover{background:#d5601a;box-shadow:0 2px 4px #ee6b1e4d}.logout-btn[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:13px}.logout-btn[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-weight:500}@media screen and (max-width: 768px){.modern-toolbar[_ngcontent-%COMP%]{padding:8px 16px;height:56px}.nav-center[_ngcontent-%COMP%]{gap:4px}.nav-link[_ngcontent-%COMP%]{padding:8px 12px;font-size:13px}.nav-link[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:none}.nav-icon[_ngcontent-%COMP%]{font-size:18px}.logo-image[_ngcontent-%COMP%]{height:32px}.user-actions[_ngcontent-%COMP%]{min-width:auto;gap:8px}.user-info[_ngcontent-%COMP%]{display:none}.user-profile[_ngcontent-%COMP%]{padding:6px}.logout-btn[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:none}.logout-btn[_ngcontent-%COMP%]{padding:8px}}@media screen and (max-width: 480px){.logo-container[_ngcontent-%COMP%]{min-width:auto}.nav-center[_ngcontent-%COMP%]{gap:2px}.nav-link[_ngcontent-%COMP%]{padding:6px 8px}}']})}}return e})();export{gt as a};
/*! Bundled license information:

@angular/flex-layout/fesm2020/angular-flex-layout-extended.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-extended.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-extended.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-extended.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-extended.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-extended.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-extended.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-flex.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout-grid.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)

@angular/flex-layout/fesm2020/angular-flex-layout.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)
*/
