import {VideoRTC} from './video-rtc.js';

/**
 * Enhanced VideoStream - Modernized wrapper for VideoRTC player
 * Version 2.0.0 - Updated with modern JavaScript patterns and better UI
 * 
 * Features:
 * - Improved status display with connection quality
 * - Better error handling and user feedback
 * - Stream quality indicators
 * - Enhanced mode detection and display
 * - Responsive UI with modern styling
 */
class VideoStream extends VideoRTC {
    constructor() {
        super();
        
        // Enhanced state tracking
        this.connectionQuality = 'unknown';
        this.statsInterval = null;
        this.lastStatsUpdate = 0;
    }

    set divMode(value) {
        const modeEl = this.querySelector('.mode');
        const statusEl = this.querySelector('.status');
        if (modeEl) {
            modeEl.innerText = value;
            modeEl.className = `mode mode-${value.toLowerCase()}`;
        }
        if (statusEl) {
            statusEl.innerText = '';
        }
    }

    set divError(value) {
        const modeEl = this.querySelector('.mode');
        const statusEl = this.querySelector('.status');
        const state = modeEl?.innerText;
        if (state !== 'loading') return;
        if (modeEl) {
            modeEl.innerText = 'error';
            modeEl.className = 'mode mode-error';
        }
        if (statusEl) {
            statusEl.innerText = value;
            statusEl.className = 'status status-error';
        }
    }

    /**
     * Update quality indicator based on stream stats
     */
    updateQualityIndicator(quality) {
        const qualityEl = this.querySelector('.quality-indicator');
        if (qualityEl) {
            qualityEl.className = `quality-indicator quality-${quality}`;
            qualityEl.setAttribute('title', `Connection: ${quality}`);
        }
    }

    /**
     * Update stream information display
     */
    updateStreamInfo(info) {
        const infoEl = this.querySelector('.stream-info');
        if (infoEl && info) {
            infoEl.innerText = info;
        }
    }

    /**
     * Enhanced Custom GUI with modern styling and quality indicators
     */
    oninit() {
        console.debug('stream.oninit');
        super.oninit();

        this.innerHTML = `
        <style>
        video-stream {
            position: relative;
            display: block;
            width: 100%;
            height: 100%;
            background: #000;
        }
        
        .info {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            padding: 12px 16px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            pointer-events: none;
            background: linear-gradient(180deg, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, transparent 100%);
            z-index: 10;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            transition: opacity 0.3s ease;
        }

        .info:hover {
            opacity: 1;
        }
        
        .status {
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .status-error {
            color: #ff6b6b;
        }
        
        .mode {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 4px 10px;
            border-radius: 4px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(4px);
            transition: all 0.3s ease;
        }

        .mode-webrtc {
            background: rgba(76, 175, 80, 0.3);
            border: 1px solid rgba(76, 175, 80, 0.5);
        }

        .mode-mse {
            background: rgba(33, 150, 243, 0.3);
            border: 1px solid rgba(33, 150, 243, 0.5);
        }

        .mode-hls {
            background: rgba(255, 152, 0, 0.3);
            border: 1px solid rgba(255, 152, 0, 0.5);
        }

        .mode-mjpeg {
            background: rgba(156, 39, 176, 0.3);
            border: 1px solid rgba(156, 39, 176, 0.5);
        }

        .mode-mp4 {
            background: rgba(0, 188, 212, 0.3);
            border: 1px solid rgba(0, 188, 212, 0.5);
        }

        .mode-error {
            background: rgba(244, 67, 54, 0.3);
            border: 1px solid rgba(244, 67, 54, 0.5);
        }

        .mode-loading {
            background: rgba(255, 255, 255, 0.2);
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .quality-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 6px;
        }

        .quality-excellent { background: #4caf50; box-shadow: 0 0 6px #4caf50; }
        .quality-good { background: #8bc34a; box-shadow: 0 0 6px #8bc34a; }
        .quality-fair { background: #ff9800; box-shadow: 0 0 6px #ff9800; }
        .quality-poor { background: #f44336; box-shadow: 0 0 6px #f44336; }
        .quality-unknown { background: #9e9e9e; }

        .stream-info {
            font-size: 11px;
            opacity: 0.8;
            margin-left: 8px;
        }

        .reconnect-info {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.85);
            padding: 20px 30px;
            border-radius: 8px;
            color: white;
            text-align: center;
            z-index: 20;
            backdrop-filter: blur(10px);
        }

        .reconnect-info .spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid #fff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 12px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        </style>
        <div class="info">
            <div class="status">
                <span class="quality-indicator quality-unknown"></span>
                <span class="status-text"></span>
                <span class="stream-info"></span>
            </div>
            <div class="mode mode-loading">Loading</div>
        </div>
        `;

        const info = this.querySelector('.info');
        this.insertBefore(this.video, info);

        // Set up event listeners for enhanced feedback
        this.setupEnhancedEventListeners();
    }

    /**
     * Set up modern event listeners for better user feedback
     */
    setupEnhancedEventListeners() {
        // Listen to custom events from VideoRTC
        this.on('connectionRestored', () => {
            this.connectionQuality = 'good';
            this.updateQualityIndicator('good');
            this.removeReconnectOverlay();
        });

        this.on('reconnecting', (e) => {
            this.showReconnectOverlay(e.detail.attempt);
        });

        this.on('maxReconnectAttemptsReached', () => {
            this.divError = 'Connection failed. Please refresh the page.';
            this.removeReconnectOverlay();
        });

        this.on('playbackError', () => {
            this.connectionQuality = 'poor';
            this.updateQualityIndicator('poor');
        });

        // Start periodic stats monitoring
        this.startStatsMonitoring();
    }

    /**
     * Show reconnection overlay
     */
    showReconnectOverlay(attempt) {
        let overlay = this.querySelector('.reconnect-info');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.className = 'reconnect-info';
            this.appendChild(overlay);
        }
        overlay.innerHTML = `
            <div class="spinner"></div>
            <div>Reconnecting...</div>
            <div style="font-size: 12px; margin-top: 8px; opacity: 0.7;">Attempt ${attempt}</div>
        `;
    }

    /**
     * Remove reconnection overlay
     */
    removeReconnectOverlay() {
        const overlay = this.querySelector('.reconnect-info');
        if (overlay) {
            overlay.remove();
        }
    }

    /**
     * Start monitoring stream statistics
     */
    startStatsMonitoring() {
        if (this.statsInterval) return;
        
        this.statsInterval = setInterval(async () => {
            const stats = await this.getStats();
            if (!stats) {
                // Stats unavailable (connection closed/failed), stop monitoring
                this.stopStatsMonitoring();
                return;
            }
            if (stats && stats.video) {
                const info = `${this.streamQuality.resolution} @ ${Math.round(this.streamQuality.fps)}fps`;
                this.updateStreamInfo(info);
                
                // Update quality based on packet loss
                if (stats.video.packetsLost !== undefined && stats.video.packetsReceived) {
                    const lossRate = stats.video.packetsLost / stats.video.packetsReceived;
                    if (lossRate < 0.01) this.updateQualityIndicator('excellent');
                    else if (lossRate < 0.05) this.updateQualityIndicator('good');
                    else if (lossRate < 0.1) this.updateQualityIndicator('fair');
                    else this.updateQualityIndicator('poor');
                }
            }
        }, 2000);
    }

    /**
     * Stop monitoring stream statistics
     */
    stopStatsMonitoring() {
        if (this.statsInterval) {
            clearInterval(this.statsInterval);
            this.statsInterval = null;
        }
    }

    onconnect() {
        console.debug('stream.onconnect');
        const result = super.onconnect();
        if (result) {
            this.divMode = 'Loading';
            this.updateQualityIndicator('unknown');
        }
        return result;
    }

    ondisconnect() {
        console.debug('stream.ondisconnect');
        this.stopStatsMonitoring();
        super.ondisconnect();
    }

    onopen() {
        console.debug('stream.onopen');
        const result = super.onopen();

        this.onmessage['stream'] = msg => {
            console.debug('stream.onmessage', msg);
            switch (msg.type) {
                case 'error':
                    this.divError = msg.value;
                    this.updateQualityIndicator('poor');
                    break;
                case 'mse':
                    this.divMode = 'MSE';
                    this.updateQualityIndicator('good');
                    break;
                case 'hls':
                    this.divMode = 'HLS';
                    this.updateQualityIndicator('good');
                    break;
                case 'mp4':
                    this.divMode = 'MP4';
                    this.updateQualityIndicator('fair');
                    break;
                case 'mjpeg':
                    this.divMode = 'MJPEG';
                    this.updateQualityIndicator('fair');
                    break;
            }
        };

        return result;
    }

    onclose() {
        console.debug('stream.onclose');
        this.updateQualityIndicator('unknown');
        return super.onclose();
    }

    onpcvideo(ev) {
        console.debug('stream.onpcvideo');
        super.onpcvideo(ev);

        if (this.pcState !== WebSocket.CLOSED) {
            this.divMode = 'WebRTC';
            this.updateQualityIndicator('excellent');
        }
    }

    /**
     * Enhanced destroy with stats cleanup
     */
    destroy() {
        this.stopStatsMonitoring();
        super.destroy();
    }
}

customElements.define('video-stream', VideoStream);

// Export for module usage
export { VideoStream };
