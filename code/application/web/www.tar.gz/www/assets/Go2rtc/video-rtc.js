/**
 * VideoRTC v2.0.0 - Modernized video player for go2rtc streaming application.
 *
 * Enhanced with modern ES2023+ features and improved error handling.
 *
 * Support:
 * - ECMAScript 2023+ (ES14) = ES6 + async/await + modern features
 * - RTCPeerConnection for Safari iOS 11.0+
 * - IntersectionObserver for Safari iOS 12.2+
 * - ManagedMediaSource for Safari 17+
 * - Enhanced state management and event handling
 * - Improved reconnection logic and error recovery
 *
 * Doesn't support:
 * - MediaSource for Safari iOS
 * - Customized built-in elements (extends HTMLVideoElement) because Safari
 * - Autoplay for WebRTC in Safari
 * 
 * Events:
 * - wsStateChange: Fired when WebSocket state changes (CONNECTING, OPEN, CLOSED)
 * - pcStateChange: Fired when PeerConnection state changes (CONNECTING, OPEN, CLOSED)
 * - disconnecting: Fired before disconnection begins
 * - disconnected: Fired after disconnection completes
 * - peerConnectionClosed: Fired when peer connection closes/fails
 * - modesInitialized: Fired when streaming modes are initialized
 * - connectionClosed: Fired when connection closes
 * - maxReconnectAttemptsReached: Fired when reconnection attempts exhausted
 * - reconnecting: Fired when attempting to reconnect
 * 
 * Usage example:
 * const player = document.querySelector('video-rtc');
 * player.addEventListener('wsStateChange', (e) => {
 *   console.log('WebSocket state:', e.detail.state, e.detail.wsState);
 * });
 * player.addEventListener('pcStateChange', (e) => {
 *   console.log('PeerConnection state:', e.detail.state, e.detail.pcState);
 * });
 */
export class VideoRTC extends HTMLElement {
    // Static constants
    static VERSION = '2.0.0';
    static STATES = {
        CONNECTING: WebSocket.CONNECTING,
        OPEN: WebSocket.OPEN,
        CLOSED: WebSocket.CLOSED
    };

    constructor() {
        super();

        this.DISCONNECT_TIMEOUT = 5000;
        this.RECONNECT_TIMEOUT = 15000;
        this.MAX_RECONNECT_ATTEMPTS = 10;
        this.RECONNECT_BACKOFF_MULTIPLIER = 1.5;

        this.CODECS = [
            'avc1.640029',      // H.264 high 4.1 (Chromecast 1st and 2nd Gen)
            'avc1.64002A',      // H.264 high 4.2 (Chromecast 3rd Gen)
            'avc1.640033',      // H.264 high 5.1 (Chromecast with Google TV)
            'hvc1.1.6.L153.B0', // H.265 main 5.1 (Chromecast Ultra)
            'mp4a.40.2',        // AAC LC
            'mp4a.40.5',        // AAC HE
            'flac',             // FLAC (PCM compatible)
            'opus',             // OPUS Chrome, Firefox
        ];

        // Enhanced state tracking
        this.reconnectAttempts = 0;
        this.lastError = null;
        this.streamQuality = {
            bitrate: 0,
            fps: 0,
            resolution: '',
            codec: ''
        };
        this.eventListeners = new Map();

        /**
         * [config] Supported modes (webrtc, webrtc/tcp, mse, hls, mp4, mjpeg).
         * @type {string}
         */
        this.mode = 'webrtc,mse,hls,mjpeg';

        /**
         * [Config] Requested medias (video, audio, microphone).
         * @type {string}
         */
        this.media = 'video,audio';

        /**
         * [config] Run stream when not displayed on the screen. Default `false`.
         * @type {boolean}
         */
        this.background = false;

        /**
         * [config] Run stream only when player in the viewport. Stop when user scroll out player.
         * Value is percentage of visibility from `0` (not visible) to `1` (full visible).
         * Default `0` - disable;
         * @type {number}
         */
        this.visibilityThreshold = 0;

        /**
         * [config] Run stream only when browser page on the screen. Stop when user change browser
         * tab or minimise browser windows.
         * @type {boolean}
         */
        this.visibilityCheck = true;

        /**
         * [config] WebRTC configuration
         * @type {RTCConfiguration}
         */
        this.pcConfig = {
            bundlePolicy: 'max-bundle',
            iceServers: [{urls: 'stun:stun.l.google.com:19302'}],
            sdpSemantics: 'unified-plan',  // important for Chromecast 1
        };

        /**
         * [info] WebSocket connection state. Values: CONNECTING, OPEN, CLOSED
         * @type {number}
         */
        this.wsState = WebSocket.CLOSED;

        /**
         * [info] WebRTC connection state.
         * @type {number}
         */
        this.pcState = WebSocket.CLOSED;

        /**
         * @type {HTMLVideoElement}
         */
        this.video = null;

        /**
         * @type {WebSocket}
         */
        this.ws = null;

        /**
         * @type {string|URL}
         */
        this.wsURL = '';

        /**
         * @type {RTCPeerConnection}
         */
        this.pc = null;

        /**
         * @type {number}
         */
        this.connectTS = 0;

        /**
         * @type {string}
         */
        this.mseCodecs = '';

        /**
         * [internal] Disconnect TimeoutID.
         * @type {number}
         */
        this.disconnectTID = 0;

        /**
         * [internal] Reconnect TimeoutID.
         * @type {number}
         */
        this.reconnectTID = 0;

        /**
         * [internal] Handler for receiving Binary from WebSocket.
         * @type {Function}
         */
        this.ondata = null;

        /**
         * [internal] Handlers list for receiving JSON from WebSocket.
         * @type {Object.<string,Function>}
         */
        this.onmessage = null;
    }

    /**
     * Set video source (WebSocket URL). Support relative path.
     * @param {string|URL} value
     */
    set src(value) {
        if (typeof value !== 'string') value = value.toString();
        if (value.startsWith('http')) {
            value = 'ws' + value.substring(4);
        } else if (value.startsWith('/')) {
            value = 'ws' + location.origin.substring(4) + value;
        }

        // Check if URL is actually changing
        const isNewUrl = this.wsURL !== value;
        this.wsURL = value;

        // If switching to a different stream, disconnect first
        if (isNewUrl && (this.ws || this.pc)) {
            this.ondisconnect();
            // Small delay to ensure cleanup completes before reconnecting
            setTimeout(() => this.onconnect(), 50);
        } else {
            this.onconnect();
        }
    }

    /**
     * Play video. Support automute when autoplay blocked.
     * Enhanced with better error handling and promise return.
     * https://developer.chrome.com/blog/autoplay/
     * @returns {Promise<boolean>} True if playback started successfully
     */
    async play() {
        try {
            await this.video.play();
            return true;
        } catch (error) {
            console.warn('Initial play failed:', error);
            if (!this.video.muted) {
                this.video.muted = true;
                try {
                    await this.video.play();
                    return true;
                } catch (muteError) {
                    console.error('Muted play also failed:', muteError);
                    this.emitEvent('playbackError', { error: muteError });
                    return false;
                }
            }
            return false;
        }
    }

    /**
     * Pause video playback
     */
    pause() {
        if (this.video) {
            this.video.pause();
        }
    }

    /**
     * Toggle mute state
     * @returns {boolean} New mute state
     */
    toggleMute() {
        if (this.video) {
            this.video.muted = !this.video.muted;
            this.emitEvent('muteChanged', { muted: this.video.muted });
            return this.video.muted;
        }
        return false;
    }

    /**
     * Set volume (0-1)
     * @param {number} volume - Volume level between 0 and 1
     */
    setVolume(volume) {
        if (this.video && volume >= 0 && volume <= 1) {
            this.video.volume = volume;
            this.emitEvent('volumeChanged', { volume });
        }
    }

    /**
     * Get current playback state
     * @returns {Object} Current state information
     */
    getState() {
        return {
            wsState: this.wsState,
            pcState: this.pcState,
            reconnectAttempts: this.reconnectAttempts,
            lastError: this.lastError,
            streamQuality: { ...this.streamQuality },
            isPlaying: this.video && !this.video.paused,
            isMuted: this.video && this.video.muted,
            volume: this.video ? this.video.volume : 0
        };
    }

    /**
     * Emit custom events
     * @param {string} eventName - Event name
     * @param {Object} detail - Event details
     */
    emitEvent(eventName, detail = {}) {
        const event = new CustomEvent(eventName, { 
            detail: { ...detail, timestamp: Date.now() },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }

    /**
     * Add event listener with automatic cleanup
     * @param {string} eventName - Event name
     * @param {Function} handler - Event handler
     */
    on(eventName, handler) {
        if (!this.eventListeners.has(eventName)) {
            this.eventListeners.set(eventName, []);
        }
        this.eventListeners.get(eventName).push(handler);
        this.addEventListener(eventName, handler);
    }

    /**
     * Remove event listener
     * @param {string} eventName - Event name
     * @param {Function} handler - Event handler
     */
    off(eventName, handler) {
        const handlers = this.eventListeners.get(eventName);
        if (handlers) {
            const index = handlers.indexOf(handler);
            if (index > -1) {
                handlers.splice(index, 1);
            }
        }
        this.removeEventListener(eventName, handler);
    }

    /**
     * Send message to server via WebSocket with error handling
     * @param {Object} value - Message to send
     * @returns {boolean} True if message was sent
     */
    send(value) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            try {
                this.ws.send(JSON.stringify(value));
                return true;
            } catch (error) {
                console.error('Failed to send WebSocket message:', error);
                this.lastError = error;
                return false;
            }
        }
        console.warn('WebSocket not ready, message not sent:', value);
        return false;
    }

    /** @param {Function} isSupported */
    codecs(isSupported) {
        return this.CODECS
            .filter(codec => this.media.indexOf(codec.indexOf('vc1') > 0 ? 'video' : 'audio') >= 0)
            .filter(codec => isSupported(`video/mp4; codecs="${codec}"`)).join();
    }

    /**
     * `CustomElement`. Invoked each time the custom element is appended into a
     * document-connected element.
     */
    connectedCallback() {
        if (this.disconnectTID) {
            clearTimeout(this.disconnectTID);
            this.disconnectTID = 0;
        }

        // because video autopause on disconnected from DOM
        if (this.video) {
            const seek = this.video.seekable;
            if (seek.length > 0) {
                this.video.currentTime = seek.end(seek.length - 1);
            }
            this.play();
        } else {
            this.oninit();
        }

        this.onconnect();
    }

    /**
     * `CustomElement`. Invoked each time the custom element is disconnected from the
     * document's DOM.
     */
    disconnectedCallback() {
        if (this.background || this.disconnectTID) return;
        if (this.wsState === WebSocket.CLOSED && this.pcState === WebSocket.CLOSED) return;

        this.disconnectTID = setTimeout(() => {
            if (this.reconnectTID) {
                clearTimeout(this.reconnectTID);
                this.reconnectTID = 0;
            }

            this.disconnectTID = 0;

            this.ondisconnect();
        }, this.DISCONNECT_TIMEOUT);
    }

    /**
     * Creates child DOM elements. Called automatically once on `connectedCallback`.
     */
    oninit() {
        this.video = document.createElement('video');
        this.video.controls = false;
        this.video.playsInline = true;
        this.video.preload = 'auto';

        this.video.style.display = 'block'; // fix bottom margin 4px
        this.video.style.width = '100%';
        this.video.style.height = '100%';

        this.appendChild(this.video);

        this.video.addEventListener('error', ev => {
            console.warn(ev);
            if (this.ws) this.ws.close(); // run reconnect for broken MSE stream
        });

        // all Safari lies about supported audio codecs
        const m = window.navigator.userAgent.match(/Version\/(\d+).+Safari/);
        if (m) {
            // AAC from v13, FLAC from v14, OPUS - unsupported
            const skip = m[1] < '13' ? 'mp4a.40.2' : m[1] < '14' ? 'flac' : 'opus';
            this.CODECS.splice(this.CODECS.indexOf(skip));
        }

        if (this.background) return;

        if ('hidden' in document && this.visibilityCheck) {
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    this.disconnectedCallback();
                } else if (this.isConnected) {
                    this.connectedCallback();
                }
            });
        }

        if ('IntersectionObserver' in window && this.visibilityThreshold) {
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (!entry.isIntersecting) {
                        this.disconnectedCallback();
                    } else if (this.isConnected) {
                        this.connectedCallback();
                    }
                });
            }, {threshold: this.visibilityThreshold});
            observer.observe(this);
        }
    }

    /**
     * Connect to WebSocket. Called automatically on `connectedCallback`.
     * @return {boolean} true if the connection has started.
     */
    onconnect() {
        if (!this.isConnected || !this.wsURL || this.ws || this.pc) return false;

        // CLOSED or CONNECTING => CONNECTING
        this.wsState = WebSocket.CONNECTING;
        this.emitEvent('wsStateChange', { state: 'CONNECTING', wsState: this.wsState });

        this.connectTS = Date.now();

        this.ws = new WebSocket(this.wsURL);
        this.ws.binaryType = 'arraybuffer';
        this.ws.addEventListener('open', () => this.onopen());
        this.ws.addEventListener('close', () => this.onclose());

        return true;
    }

    /**
     * Disconnect from all connections and cleanup resources
     * Properly stops all tracks and closes connections
     */
    ondisconnect() {
        this.emitEvent('disconnecting');

        this.wsState = WebSocket.CLOSED;
        this.emitEvent('wsStateChange', { state: 'CLOSED', wsState: this.wsState });
        
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }

        this.pcState = WebSocket.CLOSED;
        this.emitEvent('pcStateChange', { state: 'CLOSED', pcState: this.pcState });
        
        if (this.pc) {
            // Properly cleanup all senders and their tracks
            this.pc.getSenders().forEach(sender => {
                sender.track?.stop();
            });
            
            // Cleanup all receivers
            this.pc.getReceivers().forEach(receiver => {
                receiver.track?.stop();
            });
            
            this.pc.close();
            this.pc = null;
        }

        // Clear video sources
        if (this.video) {
            this.video.src = '';
            this.video.srcObject = null;
            this.video.load(); // Reset video element state
        }

        // Clear handlers
        this.ondata = null;
        this.onmessage = {};

        this.emitEvent('disconnected');
    }

    /**
     * @returns {Array.<string>} of modes (mse, webrtc, etc.)
     */
    onopen() {
        // CONNECTING => OPEN
        this.wsState = WebSocket.OPEN;
        this.emitEvent('wsStateChange', { state: 'OPEN', wsState: this.wsState });

        // Reset reconnection state on successful connection
        this.resetReconnectionState();

        this.ws.addEventListener('message', ev => {
            if (typeof ev.data === 'string') {
                const msg = JSON.parse(ev.data);
                for (const mode in this.onmessage) {
                    this.onmessage[mode](msg);
                }
            } else {
                this.ondata?.(ev.data);
            }
        });

        this.ondata = null;
        this.onmessage = {};

        const modes = [];

        if (this.mode.indexOf('mse') >= 0 && ('MediaSource' in window || 'ManagedMediaSource' in window)) {
            modes.push('mse');
            this.onmse();
        } else if (this.mode.indexOf('hls') >= 0 && this.video.canPlayType('application/vnd.apple.mpegurl')) {
            modes.push('hls');
            this.onhls();
        } else if (this.mode.indexOf('mp4') >= 0) {
            modes.push('mp4');
            this.onmp4();
        }

        if (this.mode.indexOf('webrtc') >= 0 && 'RTCPeerConnection' in window) {
            modes.push('webrtc');
            this.onwebrtc();
        }

        if (this.mode.indexOf('mjpeg') >= 0) {
            if (modes.length) {
                this.onmessage['mjpeg'] = msg => {
                    if (msg.type !== 'error' || msg.value.indexOf(modes[0]) !== 0) return;
                    this.onmjpeg();
                };
            } else {
                modes.push('mjpeg');
                this.onmjpeg();
            }
        }

        this.emitEvent('modesInitialized', { modes });
        return modes;
    }

    /**
     * @return {boolean} true if reconnection has started.
     */
    onclose() {
        if (this.wsState === WebSocket.CLOSED) return false;

        // CONNECTING, OPEN => CONNECTING
        this.wsState = WebSocket.CONNECTING;
        this.emitEvent('wsStateChange', { state: 'CONNECTING', wsState: this.wsState });
        this.ws = null;

        this.emitEvent('connectionClosed', { 
            attempts: this.reconnectAttempts,
            willReconnect: this.reconnectAttempts < this.MAX_RECONNECT_ATTEMPTS
        });

        // Check if we've exceeded max reconnect attempts
        if (this.reconnectAttempts >= this.MAX_RECONNECT_ATTEMPTS) {
            console.error(`Max reconnection attempts (${this.MAX_RECONNECT_ATTEMPTS}) reached`);
            this.emitEvent('maxReconnectAttemptsReached', { attempts: this.reconnectAttempts });
            this.wsState = WebSocket.CLOSED;
            return false;
        }

        // Calculate delay with exponential backoff
        const baseDelay = this.RECONNECT_TIMEOUT;
        const backoffDelay = baseDelay * Math.pow(this.RECONNECT_BACKOFF_MULTIPLIER, this.reconnectAttempts);
        const delay = Math.max(
            Math.min(backoffDelay, 60000), // Cap at 60 seconds
            baseDelay - (Date.now() - this.connectTS)
        );

        this.reconnectAttempts++;

        this.reconnectTID = setTimeout(() => {
            this.reconnectTID = 0;
            console.log(`Reconnection attempt ${this.reconnectAttempts}/${this.MAX_RECONNECT_ATTEMPTS}`);
            this.emitEvent('reconnecting', { attempt: this.reconnectAttempts });
            this.onconnect();
        }, delay);

        return true;
    }

    /**
     * Reset reconnection state on successful connection
     * Clears error state and reconnection counter
     */
    resetReconnectionState() {
        this.reconnectAttempts = 0;
        this.lastError = null;
        this.emitEvent('connectionRestored');
    }

    /**
     * Initialize Media Source Extensions (MSE) streaming mode
     * Supports both standard MediaSource and ManagedMediaSource (Safari 17+)
     */
    onmse() {
        /** @type {MediaSource} */
        let ms;

        if ('ManagedMediaSource' in window) {
            const MediaSource = window.ManagedMediaSource;

            ms = new MediaSource();
            ms.addEventListener('sourceopen', () => {
                this.send({type: 'mse', value: this.codecs(MediaSource.isTypeSupported)});
            }, {once: true});

            this.video.disableRemotePlayback = true;
            this.video.srcObject = ms;
        } else {
            ms = new MediaSource();
            ms.addEventListener('sourceopen', () => {
                URL.revokeObjectURL(this.video.src);
                this.send({type: 'mse', value: this.codecs(MediaSource.isTypeSupported)});
            }, {once: true});

            this.video.src = URL.createObjectURL(ms);
            this.video.srcObject = null;
        }

        this.play();

        this.mseCodecs = '';

        this.onmessage['mse'] = msg => {
            if (msg.type !== 'mse') return;

            this.mseCodecs = msg.value;

            const sb = ms.addSourceBuffer(msg.value);
            sb.mode = 'segments'; // segments or sequence
            sb.addEventListener('updateend', () => {
                if (!sb.updating && bufLen > 0) {
                    try {
                        const data = buf.slice(0, bufLen);
                        sb.appendBuffer(data);
                        bufLen = 0;
                    } catch (e) {
                        // console.debug(e);
                    }
                }

                if (!sb.updating && sb.buffered && sb.buffered.length) {
                    const end = sb.buffered.end(sb.buffered.length - 1);
                    const start = end - 5;
                    const start0 = sb.buffered.start(0);
                    if (start > start0) {
                        sb.remove(start0, start);
                        ms.setLiveSeekableRange(start, end);
                    }
                    if (this.video.currentTime < start) {
                        this.video.currentTime = start;
                    }
                    const gap = end - this.video.currentTime;
                    this.video.playbackRate = gap > 0.1 ? gap : 0.1;
                    // console.debug('VideoRTC.buffered', gap, this.video.playbackRate, this.video.readyState);
                }
            });

            const buf = new Uint8Array(2 * 1024 * 1024);
            let bufLen = 0;

            this.ondata = data => {
                if (sb.updating || bufLen > 0) {
                    const b = new Uint8Array(data);
                    buf.set(b, bufLen);
                    bufLen += b.byteLength;
                    // console.debug('VideoRTC.buffer', b.byteLength, bufLen);
                } else {
                    try {
                        sb.appendBuffer(data);
                    } catch (e) {
                        // console.debug(e);
                    }
                }
            };
        };
    }

    /**
     * Initialize WebRTC streaming mode
     * Handles peer connection, ICE candidates, and track management
     */
    onwebrtc() {
        const pc = new RTCPeerConnection(this.pcConfig);

        pc.addEventListener('icecandidate', ev => {
            if (ev.candidate && this.mode.indexOf('webrtc/tcp') >= 0 && ev.candidate.protocol === 'udp') return;

            const candidate = ev.candidate ? ev.candidate.toJSON().candidate : '';
            this.send({type: 'webrtc/candidate', value: candidate});
        });

        pc.addEventListener('connectionstatechange', () => {
            if (pc.connectionState === 'connected') {
                const tracks = pc.getTransceivers()
                    .filter(tr => tr.currentDirection === 'recvonly') // skip inactive
                    .map(tr => tr.receiver.track);
                /** @type {HTMLVideoElement} */
                const video2 = document.createElement('video');
                video2.addEventListener('loadeddata', () => this.onpcvideo(video2), {once: true});
                video2.srcObject = new MediaStream(tracks);
            } else if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
                pc.close(); // stop next events

                this.pcState = WebSocket.CLOSED;
                this.emitEvent('pcStateChange', { state: 'CLOSED', pcState: this.pcState, reason: pc.connectionState });
                this.pc = null;
                
                // Emit event to allow subclasses to clean up (e.g., stop stats monitoring)
                this.emitEvent('peerConnectionClosed', { state: pc.connectionState });

                this.onconnect();
            }
        });

        this.onmessage['webrtc'] = msg => {
            switch (msg.type) {
                case 'webrtc/candidate':
                    if (this.mode.indexOf('webrtc/tcp') >= 0 && msg.value.indexOf(' udp ') > 0) return;

                    pc.addIceCandidate({candidate: msg.value, sdpMid: '0'}).catch(er => {
                        console.warn(er);
                    });
                    break;
                case 'webrtc/answer':
                    pc.setRemoteDescription({type: 'answer', sdp: msg.value}).catch(er => {
                        console.warn(er);
                    });
                    break;
                case 'error':
                    if (msg.value.indexOf('webrtc/offer') < 0) return;
                    pc.close();
            }
        };

        this.createOffer(pc).then(offer => {
            this.send({type: 'webrtc/offer', value: offer.sdp});
        });

        this.pcState = WebSocket.CONNECTING;
        this.emitEvent('pcStateChange', { state: 'CONNECTING', pcState: this.pcState });
        this.pc = pc;
    }

    /**
     * @param pc {RTCPeerConnection}
     * @return {Promise<RTCSessionDescriptionInit>}
     */
    async createOffer(pc) {
        try {
            if (this.media.indexOf('microphone') >= 0) {
                const media = await navigator.mediaDevices.getUserMedia({audio: true});
                media.getTracks().forEach(track => {
                    pc.addTransceiver(track, {direction: 'sendonly'});
                });
            }
        } catch (e) {
            console.warn(e);
        }

        for (const kind of ['video', 'audio']) {
            if (this.media.indexOf(kind) >= 0) {
                pc.addTransceiver(kind, {direction: 'recvonly'});
            }
        }

        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        return offer;
    }

    /**
     * @param video2 {HTMLVideoElement}
     */
    onpcvideo(video2) {
        if (this.pc) {
            // Video+Audio > Video, H265 > H264, Video > Audio, WebRTC > MSE
            let rtcPriority = 0, msePriority = 0;

            /** @type {MediaStream} */
            const stream = video2.srcObject;
            if (stream.getVideoTracks().length > 0) rtcPriority += 0x220;
            if (stream.getAudioTracks().length > 0) rtcPriority += 0x102;

            if (this.mseCodecs.indexOf('hvc1.') >= 0) msePriority += 0x230;
            if (this.mseCodecs.indexOf('avc1.') >= 0) msePriority += 0x210;
            if (this.mseCodecs.indexOf('mp4a.') >= 0) msePriority += 0x101;

            if (rtcPriority >= msePriority) {
                this.video.srcObject = stream;
                this.play();

                this.pcState = WebSocket.OPEN;
                this.emitEvent('pcStateChange', { state: 'OPEN', pcState: this.pcState });

                this.wsState = WebSocket.CLOSED;
                this.emitEvent('wsStateChange', { state: 'CLOSED', wsState: this.wsState, reason: 'WebRTC takeover' });
                if (this.ws) {
                    this.ws.close();
                    this.ws = null;
                }
            } else {
                this.pcState = WebSocket.CLOSED;
                this.emitEvent('pcStateChange', { state: 'CLOSED', pcState: this.pcState, reason: 'MSE priority' });
                if (this.pc) {
                    this.pc.close();
                    this.pc = null;
                }
            }
        }

        video2.srcObject = null;
    }

    /**
     * Initialize MJPEG streaming mode
     */
    onmjpeg() {
        this.ondata = data => {
            if (this.video) {
                this.video.controls = false;
                this.video.poster = 'data:image/jpeg;base64,' + VideoRTC.btoa(data);
            }
        };

        this.send({type: 'mjpeg'});
    }

    /**
     * Initialize HLS streaming mode
     */
    onhls() {
        this.onmessage['hls'] = msg => {
            if (msg.type !== 'hls') return;

            const url = 'http' + this.wsURL.substring(2, this.wsURL.indexOf('/ws')) + '/hls/';
            const playlist = msg.value.replace('hls/', url);
            this.video.src = 'data:application/vnd.apple.mpegurl;base64,' + btoa(playlist);
            this.play();
        };

        this.send({type: 'hls', value: this.codecs(type => this.video.canPlayType(type))});
    }

    /**
     * Initialize MP4 streaming mode with canvas rendering
     */
    onmp4() {
        /** @type {HTMLCanvasElement} **/
        const canvas = document.createElement('canvas');
        /** @type {CanvasRenderingContext2D} */
        let context;

        /** @type {HTMLVideoElement} */
        const video2 = document.createElement('video');
        video2.autoplay = true;
        video2.playsInline = true;
        video2.muted = true;

        video2.addEventListener('loadeddata', () => {
            if (!context) {
                canvas.width = video2.videoWidth;
                canvas.height = video2.videoHeight;
                context = canvas.getContext('2d');
            }

            if (context && this.video) {
                context.drawImage(video2, 0, 0, canvas.width, canvas.height);
                this.video.controls = false;
                this.video.poster = canvas.toDataURL('image/jpeg');
            }
        });

        this.ondata = data => {
            video2.src = 'data:video/mp4;base64,' + VideoRTC.btoa(data);
        };

        this.send({type: 'mp4', value: this.codecs(this.video.canPlayType)});
    }

    /**
     * Convert ArrayBuffer to base64 string
     * @param {ArrayBuffer} buffer - The buffer to convert
     * @returns {string} Base64 encoded string
     */
    static btoa(buffer) {
        const bytes = new Uint8Array(buffer);
        const len = bytes.byteLength;
        let binary = '';
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return window.btoa(binary);
    }

    /**
     * Get stream statistics
     * @returns {Promise<Object>} Stream stats
     */
    async getStats() {
        // Check if peer connection exists and is in a valid state
        if (!this.pc || this.pc.connectionState === 'closed' || this.pc.connectionState === 'failed') {
            return null;
        }
        
        try {
            const stats = await this.pc.getStats();
            const result = {
                timestamp: Date.now(),
                video: {},
                audio: {},
                connection: {}
            };

            stats.forEach(report => {
                if (report.type === 'inbound-rtp') {
                    const target = report.kind === 'video' ? result.video : result.audio;
                    target.bytesReceived = report.bytesReceived;
                    target.packetsReceived = report.packetsReceived;
                    target.packetsLost = report.packetsLost;
                    if (report.kind === 'video') {
                        target.framesDecoded = report.framesDecoded;
                        target.frameWidth = report.frameWidth;
                        target.frameHeight = report.frameHeight;
                        this.streamQuality.resolution = `${report.frameWidth}x${report.frameHeight}`;
                        this.streamQuality.fps = report.framesPerSecond || 0;
                    }
                } else if (report.type === 'candidate-pair' && report.state === 'succeeded') {
                    result.connection.currentRoundTripTime = report.currentRoundTripTime;
                    result.connection.availableOutgoingBitrate = report.availableOutgoingBitrate;
                }
            });

            return result;
        } catch (error) {
            console.error('Failed to get stats:', error);
            return null;
        }
    }

    /**
     * Destroy the player and cleanup all resources
     */
    destroy() {
        // Clear all timeouts
        if (this.disconnectTID) {
            clearTimeout(this.disconnectTID);
            this.disconnectTID = 0;
        }
        if (this.reconnectTID) {
            clearTimeout(this.reconnectTID);
            this.reconnectTID = 0;
        }

        // Disconnect all connections
        this.ondisconnect();

        // Remove all event listeners
        this.eventListeners.forEach((handlers, eventName) => {
            handlers.forEach(handler => {
                this.removeEventListener(eventName, handler);
            });
        });
        this.eventListeners.clear();

        // Remove video element
        if (this.video) {
            this.video.remove();
            this.video = null;
        }

        this.emitEvent('destroyed');
    }

    /**
     * Manually retry connection
     */
    retry() {
        this.reconnectAttempts = 0;
        this.ondisconnect();
        setTimeout(() => this.onconnect(), 100);
    }
}
